# 字符串字面量之间的拼接
print("黑马"+"程序员")
# 字符串字面量和字符串变量的拼接
name = "黑马"
address = "北京"
tel = "400"
print("我是： "+ name + ",地址是：" + address + "我的电话是：" + tel)

