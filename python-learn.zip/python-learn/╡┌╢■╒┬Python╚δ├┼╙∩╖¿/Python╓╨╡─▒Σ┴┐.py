money = 50
print("当前钱包余额：", money, "元")
print("购买了冰激凌，花费：10 元")
print("购买了可乐，花费：5 元")
money = money -10 -5
print("最终，钱包剩余：", money, "元")
