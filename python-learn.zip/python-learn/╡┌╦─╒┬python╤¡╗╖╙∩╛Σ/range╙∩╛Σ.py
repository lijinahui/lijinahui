
for i in range(10,15,2):
    print(f"{i}")
