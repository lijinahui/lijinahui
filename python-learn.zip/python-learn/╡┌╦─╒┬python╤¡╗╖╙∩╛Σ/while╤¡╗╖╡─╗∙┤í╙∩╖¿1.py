"""
演示while循环的基础应用
"""
# i = 0
# while i < 100:
#     print("双宝，我喜欢你")
#     i += 1
sum = 0
i = 1
while i <= 100:
    sum += i
    i += 1
print(f"1-100累加的和是：{sum}")