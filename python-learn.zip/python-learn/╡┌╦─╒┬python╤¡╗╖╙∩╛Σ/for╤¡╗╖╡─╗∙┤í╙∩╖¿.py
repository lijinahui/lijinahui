name = "itheima is a brand of itcast"
count = 0
for i in name:

    if i == "a":
        count += 1
print(f"itheima is a brand of itcast中共含有：{count}个字母a")



