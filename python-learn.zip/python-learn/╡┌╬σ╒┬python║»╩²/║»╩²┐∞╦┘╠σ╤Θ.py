str1 = "werudhf"
str2 = "dfuiwennx"
count = 0
for i in str1:
    count += 1
print(f"字符串{str1}的长度是：{count}")
count = 0
for i in str2:
    count += 1
print(f"字符串{str2}的长度是：{count}")
