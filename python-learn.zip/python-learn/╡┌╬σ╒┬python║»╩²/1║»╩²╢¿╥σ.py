def say_hi():
    print("欢迎来到黑马程序员！\n请出示您的健康码及72小时核酸")
say_hi()
