def add(a,b):
    """
    add为两值相加
    :param a: 其中一个值
    :param b: 另一个值
    :return: 两值得和
    """
    result = a + b
    return result
r = add(5,6)
print(r)